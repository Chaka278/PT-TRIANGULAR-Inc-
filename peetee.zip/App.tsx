
import React, { useState, useContext, createContext, ReactNode, useRef, ChangeEvent, FC, useMemo, useEffect } from 'react';

// SECTION: TYPE DEFINITIONS
// =================================

type PostType = 'video' | 'picture' | 'news';
type Publicity = 'public' | 'private' | 'friends';
type Page = 
  | 'home' 
  | 'news' 
  | 'create' 
  | 'messages'
  | 'chat'
  | 'profile'
  | 'post-video'
  | 'post-picture'
  | 'post-news'
  | 'finalize-post';

interface User {
  id: string;
  name: string;
  profilePicture: string;
  followers: number;
  following: number;
  email: string;
  password?: string; 
  dob: string; 
  friends: string[]; 
  friendRequests: string[]; 
}

interface Comment {
    id: string;
    user: User;
    text: string;
    date: string;
}

interface Post {
  id: string;
  type: PostType;
  user: User;
  title: string;
  description: string;
  thumbnail: string;
  contentUrl?: string; 
  newsContent?: NewsContent;
  date: string;
  publicity: Publicity;
  likes: string[]; // Array of user IDs who liked the post
  comments: Comment[];
}

interface Message {
    id: string;
    senderId: string;
    receiverId: string;
    text: string;
    timestamp: number;
}

interface NewsContent {
  text: string;
  images: string[];
  videoUrls: string[];
  links: string[];
}

interface PostDraft {
    type: PostType;
    contentUrl?: string;
    thumbnail?: string;
    newsContent?: NewsContent;
}

interface AppContextType {
  currentUser: User | null;
  users: User[];
  posts: Post[];
  messages: Message[];
  addPost: (post: Omit<Post, 'id' | 'date' | 'user' | 'likes' | 'comments'>) => void;
  toggleLikePost: (postId: string) => void;
  addComment: (postId: string, text: string) => void;
  page: Page;
  setPage: (page: Page) => void;
  postDraft: PostDraft | null;
  setPostDraft: React.Dispatch<React.SetStateAction<PostDraft | null>>;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string, dob: string) => { success: boolean, message: string };
  logout: () => void;
  sendFriendRequest: (receiverId: string) => void;
  acceptFriendRequest: (senderId: string) => void;
  declineFriendRequest: (senderId: string) => void;
  sendMessage: (receiverId: string, text: string) => void;
  activeChatUser: User | null;
  setActiveChatUser: React.Dispatch<React.SetStateAction<User | null>>;
}

// SECTION: ICONS
// =================================

const HomeIcon = ({ active }: { active: boolean }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${active ? 'text-indigo-400' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

const NewsIcon = ({ active }: { active: boolean }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${active ? 'text-indigo-400' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3h2m-2 4h2m-2 4h2m-2 4h2" />
  </svg>
);

const PlusIcon = ({ active }: { active: boolean }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${active ? 'text-indigo-400' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const MessageIcon = ({ active }: { active: boolean }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${active ? 'text-indigo-400' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
);

const ProfileIcon = ({ active }: { active: boolean }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={`h-6 w-6 ${active ? 'text-indigo-400' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);

const ChevronLeftIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
    </svg>
);

const CameraIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
);

const UploadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
);

const VideoIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>;
const PictureIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>;
const ArticleIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-indigo-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
const SendIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>;

const CommentIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>;


// SECTION: MOCK DATA & CONTEXT
// =================================

const AppContext = createContext<AppContextType | null>(null);

const MOCK_USERS: User[] = [
    { id: 'user1', name: 'You', profilePicture: 'https://picsum.photos/seed/user1/100/100', followers: 0, following: 0, email: 'you@test.com', password: 'password123', dob: '2000-01-01', friends: ['user2'], friendRequests: ['user3'] },
    { id: 'user2', name: 'Alex Doe', profilePicture: 'https://picsum.photos/seed/user2/100/100', followers: 1250, following: 340, email: 'alex@test.com', password: 'password123', dob: '1998-05-15', friends: ['user1'], friendRequests: [] },
    { id: 'user3', name: 'Jane Smith', profilePicture: 'https://picsum.photos/seed/user3/100/100', followers: 800, following: 200, email: 'jane@test.com', password: 'password123', dob: '2002-11-30', friends: [], friendRequests: [] }
];

const INITIAL_POSTS: Post[] = [
    { id: 'post1', type: 'picture', user: MOCK_USERS[1], title: 'Mountain Adventures', description: 'Just reached the summit! The view is breathtaking.', thumbnail: 'https://picsum.photos/seed/mountain/600/400', date: new Date(Date.now() - 86400000).toISOString(), publicity: 'public', likes: ['user3'], comments: [{ id: 'c1', user: MOCK_USERS[2], text: 'Looks amazing!', date: new Date().toISOString() }] },
    { id: 'post2', type: 'video', user: MOCK_USERS[1], title: 'Ocean Waves', description: 'Soothing sounds of the ocean.', thumbnail: 'https://picsum.photos/seed/ocean/600/400', contentUrl: '', date: new Date(Date.now() - 172800000).toISOString(), publicity: 'public', likes: [], comments: [] },
    { id: 'post3', type: 'news', user: MOCK_USERS[2], title: 'Tech Weekly: The Rise of AI', description: 'An in-depth look at how artificial intelligence is shaping our future, from healthcare to entertainment.', thumbnail: 'https://picsum.photos/seed/tech/600/400', newsContent: { text: 'This is the full article content about the rise of AI...', images: [], videoUrls: [], links: [] }, date: new Date(Date.now() - 259200000).toISOString(), publicity: 'public', likes: ['user1', 'user2'], comments: [] }
];

const MOCK_MESSAGES: Message[] = [
    { id: 'msg1', senderId: 'user1', receiverId: 'user2', text: 'Hey Alex, how have you been?', timestamp: Date.now() - 200000 },
    { id: 'msg2', senderId: 'user2', receiverId: 'user1', text: 'Hey! Doing great, thanks for asking. Loved your recent post!', timestamp: Date.now() - 100000 },
];

const useNotifications = () => {
    const requestPermission = () => {
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    console.log('Notification permission granted.');
                }
            });
        }
    };

    const showNotification = (title: string, options?: NotificationOptions) => {
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(title, { ...options, icon: '/vite.svg' });
        }
    };

    return { requestPermission, showNotification };
};


const AppProvider = ({ children }: { children: ReactNode }) => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [users, setUsers] = useState<User[]>(MOCK_USERS);
    const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
    const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
    const [page, setPage] = useState<Page>('home');
    const [postDraft, setPostDraft] = useState<PostDraft | null>(null);
    const [activeChatUser, setActiveChatUser] = useState<User | null>(null);
    const { showNotification } = useNotifications();
    
    const addPost = (newPostData: Omit<Post, 'id' | 'date' | 'user' | 'likes' | 'comments'>) => {
        if (!currentUser) return;
        const newPost: Post = {
            ...newPostData,
            id: `post-${Date.now()}`,
            date: new Date().toISOString(),
            user: currentUser,
            likes: [],
            comments: []
        };
        setPosts(prevPosts => [newPost, ...prevPosts]);
    };

    const toggleLikePost = (postId: string) => {
        if (!currentUser) return;
        setPosts(prevPosts => prevPosts.map(p => {
            if (p.id === postId) {
                const isLiked = p.likes.includes(currentUser.id);
                const newLikes = isLiked ? p.likes.filter(uid => uid !== currentUser.id) : [...p.likes, currentUser.id];
                
                // Send notification if someone else's post is liked
                if (!isLiked && p.user.id !== currentUser.id) {
                    showNotification(`${currentUser.name} liked your post`, { body: `"${p.title}"` });
                }

                return { ...p, likes: newLikes };
            }
            return p;
        }));
    };

    const addComment = (postId: string, text: string) => {
        if (!currentUser) return;
        const newComment: Comment = {
            id: `comment-${Date.now()}`,
            user: currentUser,
            text,
            date: new Date().toISOString()
        };
        setPosts(prevPosts => prevPosts.map(p => {
            if (p.id === postId) {
                // Send notification for new comment on someone else's post
                if (p.user.id !== currentUser.id) {
                     showNotification(`${currentUser.name} commented on your post`, { body: `"${text}"` });
                }
                return { ...p, comments: [...p.comments, newComment] };
            }
            return p;
        }));
    };

    const login = (email: string, password: string): boolean => {
        const user = users.find(u => u.email === email && u.password === password);
        if (user) {
            setCurrentUser(user);
            return true;
        }
        return false;
    };
    
    const calculateAge = (dob: string): number => {
        const birthDate = new Date(dob);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age;
    };

    const signup = (name: string, email: string, password: string, dob: string): { success: boolean, message: string } => {
        if (calculateAge(dob) < 13) {
            return { success: false, message: 'You must be at least 13 years old to sign up.' };
        }
        if (users.some(u => u.email === email)) {
            return { success: false, message: 'An account with this email already exists.' };
        }
        const newUser: User = {
            id: `user-${Date.now()}`,
            name,
            email,
            password,
            dob,
            profilePicture: `https://picsum.photos/seed/user${Date.now()}/100/100`,
            followers: 0,
            following: 0,
            friends: [],
            friendRequests: [],
        };
        setUsers(prev => [...prev, newUser]);
        setCurrentUser(newUser);
        return { success: true, message: 'Account created successfully!' };
    };

    const logout = () => {
        setCurrentUser(null);
        setPage('home');
    };

    const sendFriendRequest = (receiverId: string) => {
        if (!currentUser) return;
        const receiver = users.find(u => u.id === receiverId);
        if(!receiver) return;

        setUsers(prevUsers => prevUsers.map(user => {
            if (user.id === receiverId) {
                if (!user.friendRequests.includes(currentUser.id)) {
                    showNotification(`New Friend Request`, { body: `${currentUser.name} sent you a friend request.` });
                    return { ...user, friendRequests: [...user.friendRequests, currentUser.id] };
                }
            }
            return user;
        }));
    };
    
    const acceptFriendRequest = (senderId: string) => {
        if (!currentUser) return;
        const sender = users.find(u => u.id === senderId);
        if(!sender) return;

        const newCurrentUser: User = {
            ...currentUser,
            friendRequests: currentUser.friendRequests.filter(id => id !== senderId),
            friends: [...currentUser.friends, senderId]
        };
        
        setUsers(prevUsers => prevUsers.map(user => {
            if (user.id === currentUser.id) return newCurrentUser;
            if (user.id === senderId) return { ...user, friends: [...user.friends, currentUser.id] };
            return user;
        }));
        setCurrentUser(newCurrentUser);
        showNotification(`Friend Request Accepted`, { body: `You are now friends with ${sender.name}.` });
    };
    
    const declineFriendRequest = (senderId: string) => {
        if (!currentUser) return;
         const newCurrentUser: User = {
            ...currentUser,
            friendRequests: currentUser.friendRequests.filter(id => id !== senderId)
        };
        setUsers(prevUsers => prevUsers.map(user => user.id === currentUser.id ? newCurrentUser : user));
        setCurrentUser(newCurrentUser);
    };

    const sendMessage = (receiverId: string, text: string) => {
        if(!currentUser) return;
        const newMessage: Message = {
            id: `msg-${Date.now()}`,
            senderId: currentUser.id,
            receiverId,
            text,
            timestamp: Date.now()
        };
        setMessages(prev => [...prev, newMessage]);
    };

    const contextValue = useMemo(() => ({
      currentUser, users, posts, messages, addPost, toggleLikePost, addComment, page, setPage, postDraft, setPostDraft, login, signup, logout, sendFriendRequest, acceptFriendRequest, declineFriendRequest, sendMessage, activeChatUser, setActiveChatUser
    }), [currentUser, users, posts, messages, page, postDraft, activeChatUser]);

    return (
        <AppContext.Provider value={contextValue}>
            {children}
        </AppContext.Provider>
    );
};

const useAppContext = () => {
    const context = useContext(AppContext);
    if (!context) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};

// SECTION: REUSABLE COMPONENTS
// =================================

const PostCard: FC<{ post: Post }> = ({ post }) => {
    const { currentUser, toggleLikePost, sendFriendRequest, addComment } = useAppContext();
    const [showComments, setShowComments] = useState(false);
    const [commentText, setCommentText] = useState('');

    if (!currentUser) return null;

    const isLiked = post.likes.includes(currentUser.id);
    const isFriend = post.user.id === currentUser.id || currentUser.friends.includes(post.user.id);
    const hasSentRequest = post.user.friendRequests.includes(currentUser.id);

    const handleLike = () => {
        toggleLikePost(post.id);
    }
    
    const handleAddFriend = () => {
      sendFriendRequest(post.user.id);
    }

    const handleCommentSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (commentText.trim()) {
            addComment(post.id, commentText);
            setCommentText('');
        }
    };

    return (
        <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg mb-6">
            <div className="p-4 flex items-center justify-between">
                <div className="flex items-center">
                    <img className="h-10 w-10 rounded-full object-cover" src={post.user.profilePicture} alt={`${post.user.name}'s profile`} />
                    <div className="ml-3">
                        <p className="text-sm font-semibold text-white">{post.user.name}</p>
                        <p className="text-xs text-gray-400">{new Date(post.date).toLocaleDateString()}</p>
                    </div>
                </div>
                {!isFriend && (
                    <button 
                        onClick={handleAddFriend}
                        disabled={hasSentRequest}
                        className="bg-indigo-500 text-white text-xs font-bold py-1 px-3 rounded-md disabled:bg-gray-500 disabled:cursor-not-allowed hover:bg-indigo-600">
                        {hasSentRequest ? 'Request Sent' : 'Add Friend'}
                    </button>
                )}
            </div>
            {post.thumbnail && <img className="w-full h-64 object-cover" src={post.thumbnail} alt={post.title} />}
            <div className="p-4">
                <h3 className="font-bold text-lg mb-2 text-white">{post.title}</h3>
                <p className="text-gray-300 text-sm">{post.description}</p>
            </div>
            <div className="p-4 border-t border-gray-700 flex justify-start items-center space-x-6">
                <button onClick={handleLike} className={`flex items-center space-x-2 ${isLiked ? 'text-red-500' : 'text-gray-400 hover:text-white'}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill={isLiked ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={isLiked ? 0 : 2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                    <span>{post.likes.length} {post.likes.length === 1 ? 'Like' : 'Likes'}</span>
                </button>
                <button onClick={() => setShowComments(!showComments)} className="flex items-center space-x-2 text-gray-400 hover:text-white">
                   <CommentIcon />
                    <span>{post.comments.length} {post.comments.length === 1 ? 'Comment' : 'Comments'}</span>
                </button>
            </div>
            {showComments && (
                <div className="p-4 border-t border-gray-700">
                    <div className="space-y-4 max-h-60 overflow-y-auto mb-4">
                        {post.comments.length > 0 ? post.comments.map(comment => (
                            <div key={comment.id} className="flex items-start space-x-3">
                                <img src={comment.user.profilePicture} alt={comment.user.name} className="h-8 w-8 rounded-full" />
                                <div className="bg-gray-700 p-2 rounded-lg flex-1">
                                    <p className="text-sm font-semibold">{comment.user.name}</p>
                                    <p className="text-sm text-gray-300">{comment.text}</p>
                                </div>
                            </div>
                        )) : <p className="text-sm text-gray-400">No comments yet.</p>}
                    </div>
                    <form onSubmit={handleCommentSubmit} className="flex items-center space-x-2">
                        <input 
                            type="text" 
                            value={commentText}
                            onChange={(e) => setCommentText(e.target.value)}
                            placeholder="Add a comment..." 
                            className="flex-1 bg-gray-700 rounded-full py-2 px-4 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        <button type="submit" className="bg-indigo-600 p-2 rounded-full hover:bg-indigo-700">
                            <SendIcon />
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
};

const BottomNav = () => {
    const { page, setPage } = useAppContext();
    const navItems = [
        { name: 'home', icon: <HomeIcon active={page === 'home'} />, label: 'Home' },
        { name: 'news', icon: <NewsIcon active={page === 'news'} />, label: 'News' },
        { name: 'create', icon: <PlusIcon active={page.startsWith('post-')} />, label: 'Create' },
        { name: 'messages', icon: <MessageIcon active={page === 'messages'} />, label: 'Messages' },
        { name: 'profile', icon: <ProfileIcon active={page === 'profile'} />, label: 'Profile' },
    ];

    return (
        <nav className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-700 flex justify-around items-center h-16">
            {navItems.map(item => (
                <button key={item.name} onClick={() => setPage(item.name as Page)} className="flex flex-col items-center justify-center text-gray-400 w-1/5 pt-1 hover:text-indigo-400">
                    {item.icon}
                    <span className={`text-xs mt-1 ${page === item.name || (item.name === 'create' && page.startsWith('post-')) ? 'text-indigo-400' : 'text-gray-400'}`}>{item.label}</span>
                </button>
            ))}
        </nav>
    );
};

const PageHeader = ({ title, onBack }: { title: string, onBack?: () => void }) => (
    <div className="sticky top-0 bg-gray-900/80 backdrop-blur-sm z-10 p-4 flex items-center border-b border-gray-700">
        {onBack && <button onClick={onBack} className="mr-4"><ChevronLeftIcon /></button>}
        <h1 className="text-xl font-bold">{title}</h1>
    </div>
);


// SECTION: PAGE COMPONENTS
// =================================

const HomePage = () => {
    const { posts } = useAppContext();
    return (
        <div>
            <PageHeader title="PEETEE" />
            <div className="p-4 pb-20">
                {posts.map(post => <PostCard key={post.id} post={post} />)}
            </div>
        </div>
    );
};

const NewsPage = () => {
    const { posts } = useAppContext();
    const newsPosts = posts.filter(p => p.type === 'news');
    return (
        <div>
            <PageHeader title="News" />
            <div className="p-4 pb-20">
                {newsPosts.length > 0 ? (
                    newsPosts.map(post => <PostCard key={post.id} post={post} />)
                ) : (
                    <p className="text-center text-gray-400 mt-8">No news yet.</p>
                )}
            </div>
        </div>
    );
};

const ProfilePage = () => {
    const { currentUser, posts, logout } = useAppContext();

    if (!currentUser) return null;

    const userPosts = posts.filter(p => p.user.id === currentUser.id);
    const totalLikes = userPosts.reduce((sum, post) => sum + post.likes.length, 0);

    return (
        <div className="pb-20">
             <PageHeader title="Profile" />
            <div className="p-6 bg-gray-800">
                <div className="flex items-center justify-between">
                    <div className="flex items-center">
                        <img className="h-24 w-24 rounded-full object-cover border-4 border-indigo-500" src={currentUser.profilePicture} alt="Profile" />
                        <div className="ml-6">
                            <h2 className="text-2xl font-bold">{currentUser.name}</h2>
                            <p className="text-sm text-gray-400">{currentUser.email}</p>
                        </div>
                    </div>
                     <button onClick={logout} className="text-sm bg-red-600 hover:bg-red-700 px-4 py-2 rounded-md">Logout</button>
                </div>
                <div className="mt-6 flex justify-around text-center">
                    <div>
                        <p className="font-bold text-lg">{currentUser.friends.length}</p>
                        <p className="text-sm text-gray-400">Friends</p>
                    </div>
                    <div>
                        <p className="font-bold text-lg">{currentUser.following}</p>
                        <p className="text-sm text-gray-400">Following</p>
                    </div>
                    <div>
                        <p className="font-bold text-lg">{totalLikes}</p>
                        <p className="text-sm text-gray-400">Likes</p>
                    </div>
                </div>
            </div>
            <div className="p-4">
                <h3 className="text-lg font-semibold mb-4">My Posts</h3>
                <div className="grid grid-cols-3 gap-1">
                    {userPosts.length > 0 ? (
                        userPosts.map(post => (
                            <img key={post.id} src={post.thumbnail} alt={post.title} className="w-full h-32 object-cover bg-gray-700" />
                        ))
                    ) : (
                        <p className="text-center text-gray-400 col-span-3 mt-4">You haven't posted anything yet.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

const CreatePostPage = () => {
    const { setPage, setPostDraft } = useAppContext();

    const handleSelect = (type: PostType) => {
        setPostDraft({ type });
        setPage(`post-${type}` as Page);
    };

    return (
        <div>
        <PageHeader title="Create a Post" />
        <div className="flex flex-col justify-center items-center p-4 pt-16">
            <div className="w-full max-w-sm space-y-4">
                <button onClick={() => handleSelect('video')} className="w-full bg-gray-800 hover:bg-gray-700 text-left p-4 rounded-lg flex items-center space-x-4">
                    <VideoIcon />
                    <div>
                        <p className="font-semibold">Post Video</p>
                        <p className="text-sm text-gray-400">Share a video from your gallery or camera</p>
                    </div>
                </button>
                 <button onClick={() => handleSelect('picture')} className="w-full bg-gray-800 hover:bg-gray-700 text-left p-4 rounded-lg flex items-center space-x-4">
                    <PictureIcon />
                    <div>
                        <p className="font-semibold">Post Picture</p>
                        <p className="text-sm text-gray-400">Share a picture from your gallery or camera</p>
                    </div>
                </button>
                 <button onClick={() => handleSelect('news')} className="w-full bg-gray-800 hover:bg-gray-700 text-left p-4 rounded-lg flex items-center space-x-4">
                    <ArticleIcon />
                    <div>
                        <p className="font-semibold">Post News</p>
                        <p className="text-sm text-gray-400">Write an article with text, media, and links</p>
                    </div>
                </button>
            </div>
        </div>
        </div>
    );
};

const PostMediaPage = ({ type }: { type: 'video' | 'picture' }) => {
    const { setPage, setPostDraft } = useAppContext();
    const inputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const url = URL.createObjectURL(file);
            setPostDraft(prev => ({...prev!, contentUrl: url, thumbnail: type === 'picture' ? url : undefined }));
            setPage('finalize-post');
        }
    };
    
    return (
        <div>
            <PageHeader title={type === 'video' ? "Post Video" : "Post Picture"} onBack={() => setPage('create')} />
            <div className="flex flex-col h-[calc(100vh-120px)] justify-center items-center p-4 space-y-8">
                <input type="file" ref={inputRef} onChange={handleFileChange} accept={`${type}/*`} className="hidden" />
                <button onClick={() => { inputRef.current?.setAttribute('capture', 'user'); inputRef.current?.click(); }} className="w-full max-w-sm bg-gray-800 hover:bg-gray-700 p-6 rounded-lg flex flex-col items-center space-y-3">
                    <CameraIcon />
                    <p className="font-semibold text-lg">{type === 'video' ? 'Use Camera' : 'Take Picture'}</p>
                </button>
                <button onClick={() => { inputRef.current?.removeAttribute('capture'); inputRef.current?.click(); }} className="w-full max-w-sm bg-gray-800 hover:bg-gray-700 p-6 rounded-lg flex flex-col items-center space-y-3">
                    <UploadIcon />
                    <p className="font-semibold text-lg">{type === 'video' ? 'Upload Video' : 'Upload Picture'}</p>
                </button>
            </div>
        </div>
    );
};

const PostNewsPage = () => {
    const { setPage, setPostDraft } = useAppContext();
    const [text, setText] = useState('');
    const [thumbnail, setThumbnail] = useState<string | undefined>();
    const thumbnailInputRef = useRef<HTMLInputElement>(null);

    const handleNext = () => {
        setPostDraft(prev => ({
            ...prev!,
            thumbnail,
            newsContent: {
                text,
                images: [],
                videoUrls: [],
                links: [],
            }
        }));
        setPage('finalize-post');
    }

    const handleThumbnailChange = (event: ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setThumbnail(URL.createObjectURL(file));
        }
    }

    return (
        <div>
            <PageHeader title="Post News" onBack={() => setPage('create')} />
            <div className="p-4 space-y-4 pb-20">
                <textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Write your article here..."
                    className="w-full h-64 p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
                 <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Thumbnail Image</label>
                    <div onClick={() => thumbnailInputRef.current?.click()} className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md cursor-pointer">
                        {thumbnail ? <img src={thumbnail} alt="Thumbnail preview" className="max-h-40 object-contain" /> : (
                            <div className="space-y-1 text-center">
                                <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                                <p className="text-sm text-gray-400">Click to upload</p>
                            </div>
                        )}
                    </div>
                    <input type="file" ref={thumbnailInputRef} onChange={handleThumbnailChange} accept="image/*" className="hidden" />
                </div>
                <button
                    onClick={handleNext}
                    disabled={!text || !thumbnail}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg disabled:bg-gray-500"
                >
                    Next
                </button>
            </div>
        </div>
    );
}

const FinalizePostPage = () => {
    const { setPage, postDraft, addPost } = useAppContext();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [publicity, setPublicity] = useState<Publicity>('public');
    const [thumbnail, setThumbnail] = useState(postDraft?.thumbnail);
    const thumbnailInputRef = useRef<HTMLInputElement>(null);

    if (!postDraft) {
        setPage('create');
        return null;
    }

    const handlePost = () => {
        if (!title || !description || !thumbnail) return;
        
        addPost({
            type: postDraft.type,
            title,
            description,
            publicity,
            thumbnail,
            contentUrl: postDraft.contentUrl,
            newsContent: postDraft.newsContent,
        });
        setPage('home');
    }

     const handleThumbnailChange = (event: ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setThumbnail(URL.createObjectURL(file));
        }
    }

    return (
        <div>
            <PageHeader title="Finalize Post" onBack={() => setPage(`post-${postDraft.type}` as Page)} />
            <div className="p-4 space-y-4 pb-20">
                {postDraft.type === 'video' && !thumbnail && (
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Video Thumbnail</label>
                        <div onClick={() => thumbnailInputRef.current?.click()} className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-md cursor-pointer">
                            <div className="space-y-1 text-center">
                                <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                                <p className="text-sm text-gray-400">Upload a thumbnail</p>
                            </div>
                        </div>
                        <input type="file" ref={thumbnailInputRef} onChange={handleThumbnailChange} accept="image/*" className="hidden" />
                    </div>
                )}
                {thumbnail && <img src={thumbnail} alt="Preview" className="w-full rounded-lg max-h-60 object-contain bg-black" />}

                <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="Description" className="w-full h-24 p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                
                <select value={publicity} onChange={e => setPublicity(e.target.value as Publicity)} className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none">
                    <option value="public">Public</option>
                    <option value="private">Private</option>
                    <option value="friends">Friends Only</option>
                </select>

                <button onClick={handlePost} disabled={!title || !description || !thumbnail} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg disabled:bg-gray-500">Post</button>
            </div>
        </div>
    );
};

const MessagesPage = () => {
    const { currentUser, users, acceptFriendRequest, declineFriendRequest, setPage, setActiveChatUser } = useAppContext();
    if (!currentUser) return null;

    const requestUsers = currentUser.friendRequests.map(id => users.find(u => u.id === id)).filter(Boolean) as User[];
    const friendUsers = currentUser.friends.map(id => users.find(u => u.id === id)).filter(Boolean) as User[];

    const handleChat = (user: User) => {
        setActiveChatUser(user);
        setPage('chat');
    };

    return (
        <div>
            <PageHeader title="Messages" />
            <div className="p-4 pb-20">
                {requestUsers.length > 0 && (
                    <div className="mb-6">
                        <h2 className="text-lg font-semibold text-gray-300 mb-2">Friend Requests</h2>
                        <div className="space-y-3">
                            {requestUsers.map(user => (
                                <div key={user.id} className="bg-gray-800 p-3 rounded-lg flex items-center justify-between">
                                    <div className="flex items-center">
                                        <img src={user.profilePicture} alt={user.name} className="h-10 w-10 rounded-full" />
                                        <p className="ml-3 font-semibold">{user.name}</p>
                                    </div>
                                    <div className="space-x-2">
                                        <button onClick={() => acceptFriendRequest(user.id)} className="bg-green-600 hover:bg-green-700 text-white text-xs font-bold py-1 px-3 rounded-md">Accept</button>
                                        <button onClick={() => declineFriendRequest(user.id)} className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold py-1 px-3 rounded-md">Decline</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
                <div>
                    <h2 className="text-lg font-semibold text-gray-300 mb-2">Friends</h2>
                    <div className="space-y-1">
                        {friendUsers.length > 0 ? friendUsers.map(user => (
                            <div key={user.id} onClick={() => handleChat(user)} className="bg-gray-800 hover:bg-gray-700 p-3 rounded-lg flex items-center cursor-pointer">
                                <img src={user.profilePicture} alt={user.name} className="h-12 w-12 rounded-full" />
                                <p className="ml-4 font-semibold text-lg">{user.name}</p>
                            </div>
                        )) : <p className="text-center text-gray-400 mt-4">You have no friends yet.</p>}
                    </div>
                </div>
            </div>
        </div>
    );
};

const ChatPage = () => {
    const { currentUser, activeChatUser, messages, sendMessage, setPage, setActiveChatUser } = useAppContext();
    const [text, setText] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    if(!currentUser || !activeChatUser) {
        setPage('messages');
        return null;
    }
    
    const chatMessages = messages
        .filter(m => (m.senderId === currentUser.id && m.receiverId === activeChatUser.id) || (m.senderId === activeChatUser.id && m.receiverId === currentUser.id))
        .sort((a,b) => a.timestamp - b.timestamp);
    
    const handleSend = () => {
        if(text.trim()){
            sendMessage(activeChatUser.id, text.trim());
            setText('');
            setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
        }
    };
    
    return (
        <div className="flex flex-col h-screen">
            <PageHeader title={activeChatUser.name} onBack={() => { setActiveChatUser(null); setPage('messages'); }} />
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {chatMessages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs lg:max-w-md p-3 rounded-lg ${msg.senderId === currentUser.id ? 'bg-indigo-600' : 'bg-gray-700'}`}>
                            <p>{msg.text}</p>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>
            <div className="p-4 bg-gray-900 border-t border-gray-700 flex items-center">
                <input 
                    type="text" 
                    value={text}
                    onChange={e => setText(e.target.value)}
                    onKeyPress={e => e.key === 'Enter' && handleSend()}
                    placeholder="Type a message..."
                    className="flex-1 bg-gray-800 rounded-full py-2 px-4 focus:outline-none"
                />
                <button onClick={handleSend} className="ml-3 bg-indigo-600 p-3 rounded-full hover:bg-indigo-700">
                    <SendIcon />
                </button>
            </div>
        </div>
    );
};


const AuthPage = () => {
    const [isLogin, setIsLogin] = useState(true);
    return isLogin ? <LoginPage onSwitch={() => setIsLogin(false)} /> : <SignupPage onSwitch={() => setIsLogin(true)} />;
}

const LoginPage = ({ onSwitch }: { onSwitch: () => void }) => {
    const { login } = useAppContext();
    const [email, setEmail] = useState('you@test.com');
    const [password, setPassword] = useState('password123');
    const [error, setError] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (!login(email, password)) {
            setError('Invalid email or password.');
        }
    };

    return (
        <div className="min-h-screen flex flex-col justify-center items-center bg-gray-900 p-4">
            <h1 className="text-4xl font-bold mb-2 text-indigo-400">PEETEE</h1>
            <h2 className="text-2xl font-bold mb-8">Login to your account</h2>
            <form onSubmit={handleLogin} className="w-full max-w-sm space-y-4">
                {error && <p className="text-red-500 bg-red-900/50 p-3 rounded-md text-center">{error}</p>}
                <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg">Login</button>
                <p className="text-center text-sm">
                    Don't have an account? <button type="button" onClick={onSwitch} className="text-indigo-400 hover:underline">Sign up</button>
                </p>
            </form>
        </div>
    );
};

const SignupPage = ({ onSwitch }: { onSwitch: () => void }) => {
    const { signup } = useAppContext();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [dob, setDob] = useState('');
    const [error, setError] = useState('');

    const handleSignup = (e: React.FormEvent) => {
        e.preventDefault();
        if(!name || !email || !password || !dob) {
            setError('Please fill all fields.');
            return;
        }
        const result = signup(name, email, password, dob);
        if(!result.success){
            setError(result.message);
        }
    };

    return (
        <div className="min-h-screen flex flex-col justify-center items-center bg-gray-900 p-4">
            <h1 className="text-4xl font-bold mb-2 text-indigo-400">PEETEE</h1>
            <h2 className="text-2xl font-bold mb-8">Create an account</h2>
            <form onSubmit={handleSignup} className="w-full max-w-sm space-y-4">
                 {error && <p className="text-red-500 bg-red-900/50 p-3 rounded-md text-center">{error}</p>}
                <input type="text" placeholder="Full Name" value={name} onChange={e => setName(e.target.value)} className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                <div>
                     <label className="text-sm text-gray-400 ml-1">Date of Birth</label>
                     <input type="date" value={dob} onChange={e => setDob(e.target.value)} className="w-full p-3 bg-gray-800 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none" />
                </div>
                <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg">Sign Up</button>
                 <p className="text-center text-sm">
                    Already have an account? <button type="button" onClick={onSwitch} className="text-indigo-400 hover:underline">Login</button>
                </p>
            </form>
        </div>
    );
};


// SECTION: MAIN APP COMPONENT
// =================================

// Fix: Explicitly type MainContent as a React FunctionComponent (FC).
// This helps TypeScript's type inference, which can sometimes get confused with complex components
// that use context, potentially resolving the incorrect type error about missing children.
const MainContent: FC = () => {
    const { page, currentUser } = useAppContext();
    const { requestPermission } = useNotifications();

    useEffect(() => {
        if(currentUser) {
            requestPermission();
        }
    }, [currentUser, requestPermission]);

    if (!currentUser) {
        return <AuthPage />;
    }

    const renderPage = () => {
        switch (page) {
            case 'home': return <HomePage />;
            case 'news': return <NewsPage />;
            case 'profile': return <ProfilePage />;
            case 'create': return <CreatePostPage />;
            case 'post-video': return <PostMediaPage type="video" />;
            case 'post-picture': return <PostMediaPage type="picture" />;
            case 'post-news': return <PostNewsPage />;
            case 'finalize-post': return <FinalizePostPage />;
            case 'messages': return <MessagesPage />;
            case 'chat': return <ChatPage />;
            default: return <HomePage />;
        }
    };
    
    const showNav = ['home', 'news', 'create', 'messages', 'profile'].includes(page);
    const isFullScreenPage = ['chat'];

    if (isFullScreenPage.includes(page)) {
        return renderPage();
    }

    return (
        <div className="bg-gray-900 text-white min-h-screen font-sans">
            <main className="max-w-2xl mx-auto">
              {renderPage()}
            </main>
            {showNav && <BottomNav />}
        </div>
    );
};

const App = () => {
    return (
        <AppProvider>
            <MainContent />
        </AppProvider>
    );
}

export default App;
